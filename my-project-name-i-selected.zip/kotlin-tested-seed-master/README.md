# kotlin-tested-seed

[![Build Status](https://travis-ci.org/divanvisagie/kotlin-tested-seed.svg?branch=master)](https://travis-ci.org/divanvisagie/kotlin-tested-seed)


A seed project for a tested kotlin application
